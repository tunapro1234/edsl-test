
options linesize=78 pagesize=999;
libname out '';


data all; set out.cpc15est_15comp_18est;
data e18; set out.cpc18est;

****************************Part 2: The derivation of the prediction******************;
data a; set e18;
nt=25;
N_Exp=20000; ***number of simulations;

****parameters****************************************************************;
 do kapa=3; ***sample size;
 do sig=13; ***noise standard deviation;
 do teta=.7; ***the diminishing effect of number of previous trials with feedback in this problem;
 do beta=1.4; *** the initial tendency to select the biased dist, .8 implies equal prob;
 do psi=.25; ***ambiguity parameter ******************;
 do gama=1; ***the ralative value parameter that affect pessimism *********;
 do sigcom=35;
 do wamb =.25;
output;
end; end; end; end; end; end; end; end;
 
 
data a; set a; model='BEASTsd';

array rb{5} b1-b5;
array pred{5} pred1-pred5;
array va{10} av1-av10;
array vb{10} bv1-bv10;
array pa{10} ap1-ap10;
array pb{10} bp1-bp10;
array spb{10} spb1-spb10;
array his{2,20} his1-his40;


**number of outcomes;
 nva=0; nvb=0; 
 do qq=1 to 10; if pa{qq}<0 then pa{qq}=0; if pa{qq}>0 then nva=nva+1;  end;
 do qq=1 to 10; if pb{qq}<0 then pb{qq}=0; if pb{qq}>0 then nvb=nvb+1; spb{qq}=pb{qq}; end;


***expected values*****************************;
eva=0; do i=1 to nva; eva=sum(eva,va{i}*pa{i}); end;
evb=0; do i=1 to nvb; evb=sum(evb,vb{i}*pb{i}); end;
Uall=mean(of bv1-bv10);
Uother=mean(of bv2-bv10);


**max, min, range****************************;
 minv=min(bv1,av1); maxv=max(vb{nvb},av2); range=maxv-minv;
 mina=av1; minb=bv1; maxa=va{nva}; maxb=vb{nvb};

******* contingent noise**************************;
if model='BEASTsd' then do; **************************************new BEASTsd;
nvat=nva; nvbt=nvb; 
sigt=sig;
if (min(nvat,nvbt)>1 and max(nvat,nvbt)>2) then sigt=sigcom; 
end;****on new BEASTsd;

***expected values*****************************;
ewa=0; do i=1 to nva; ewa=sum(ewa,va{i}*1/nva); end;
ewb=0; do i=1 to nvb; ewb=sum(ewb,vb{i}*1/nvb); end;
moda=0; pmaxa=0; do i=1 to nva; 
  if pa{i}>pmaxa then do; pmaxa=pa{i}; moda=va{i}; end; if pa{i}=pmaxa then do; moda=mean(va{i}, moda); end; end;
modb=0; pmaxb=0; do i=1 to nvb; 
  if pb{i}>pmaxb then do; pmaxb=pb{i}; modb=vb{i}; end; if pb{i}=pmaxb then do; modb=mean(vb{i}, modb); end;end;
Uall=mean(of bv1-bv10);
Uother=mean(of bv2-bv10);

**max, min, range****************************;
 minv=min(bv1,av1); maxv=max(vb{nvb},va{nva}); range=maxv-minv;
 mina=av1; minb=bv1; maxa=va{nva}; maxb=vb{nvb};
 
***detecting dominance************************************************************************************new BEASTsd;
 
 dom=1; maxd=0; mind=0; pabet=0; pbbet=0; 
 do zz =0 to 1 by .001;
  sumb=0; suma=0;
  do qq=1 to nva; suma=sum(suma,pa{qq}); if zz<suma then do; vat=va{qq}; qq=nva; end; end; 
  do qq=1 to nvb; sumb=sum(sumb,pb{qq}); if zz<sumb then do; vbt=vb{qq}; qq=nvb;  end; end;
  diff=vat-vbt; if diff<mind then mind=diff; if diff>maxd then maxd=diff;
  if vat>vbt then pabet=pabet+.001;
  if vat<vbt then pbbet=pbbet+.001;
  if mind<0 and maxd>0 then do; dom=0; end;
 end; 
 
if model='BEASTsd' then do;
  dom=0; 
  if eva>evb and ewa>=ewb then dom=1-pbbet;
  if eva<evb and ewa<=ewb then dom=1-pabet;
 end;
***********************end of new BEASTsd;

if Amb=1 then do; dom=0; if mina>maxb or minb>maxa then dom=1; end;

*****************************************virtual experiments*****************************;
do sim=1 to N_exp;

****individual characteristics****;
iteta=teta*ranuni(0);

isig=ranuni(0)*sigt; 

if model='BEASTsd' then isig=isig*(1-dom);******************************************************************new BEASTsd;
if model='org' and dom=1 then isig=0;
isigi=isig;

ikapa=round(.5+ranuni(0)*kapa);
ipsi=ranuni(0)*psi;
ibeta=beta*ranuni(0);
igama=gama*(ranuni(0));
iwamb=wamb*(ranuni(0));

*****The subjective expected values and subjective probabilities of the ambiguous prospects;
sevb0=evb;

*evb1=evb;
if Amb=1 then do;  
 sevb0=(1-ipsi)*mean(Uall,eva)+ipsi*(bv1);
 spb1=max(0,(sevb0-Uother)/(bv1-Uother)); if spb1>1 then spb1=1;
 do i=2 to nvb; spb{i}=(1-spb1)/(nvb-1); end;
end;
sevb=sevb0;
obbet=0; oabet=0;
b=0;
sumbb=0;

do r=1 to 25;
rfb=max(0,r-6); ***number of past trials with feedback;

Bbet=sevb-eva+isigi*rannor(0);*25/(tt+25); ***initial noisy bias;

if (r-1)/5=round((r-1)/5) then b=b+1;
***taking a sample of kapa****************************************;
do i= 1 to ikapa; 

rndsim=ranuni(0);
rnd=ranuni(0); 

***Choosing the simulation technique (simtec)**********************************;
simtec='Unbiased';  ***draw from the objective distribution;
if rndsim<ibeta/(ibeta+1+rfb**iteta) then do; *** implied by the probability of bias; 
rndd=round(.5+ranuni(0)*3);  **all the 3 bias simtec are equally likely;
  if rndd=1 then simtec='uniform';  **draw assuming  equaly likely; 
  if rndd=2 then simtec='ContPess';  **draw the worst payoff or uniform; 
  if rndd=3 then simtec='sign';  **sensitivity to payoff sign;
end; 
 
***Unbias: draw from the true distribution***************************************************************************;
if simtec='Unbiased' then do; suma=0; sumb=0; 
 if r<7  then do; **draw from payoff distribution;
  do qq=1 to nva; suma=sum(suma,pa{qq}); if suma>rnd then do; vat=va{qq}; qq=nva; end; end; 
  do qq=1 to nvb; sumb=sum(sumb,spb{qq}); if sumb>rnd then do; vbt=vb{qq}; qq=nvb; end; end;
 end;
 if  r>=7 then do; **draw from experience;
  tmp=round(.5+ranuni(0)*(r-6)); vat=his{1,tmp}; vbt=his{2,tmp};
 end;
end; ***of simtec=Unbiased;


 ***Uniform: draw from the all the probability are equaly likly ********;
 if simtec='uniform' then do; ***drawing from the list of outcomes; 
   oa=round(.5+rnd*nva);
   ob=round(.5+rnd*nvb);
   vat=va{oa};vbt=vb{ob};
 end; ***of simtec=Uniform;


 ***Contingent pessimism: draw from the pessimistic or uniform distribution************************************;

if simtec='ContPess' then do; sumb=0;**pessimism or uniform;
  vat= av1; ****basic payoff from s;
  vbt= bv1; ****basic payoff from r;
  aa=max(abs(av1),.000001); 
  bb=max(abs(bv1),.000001);
 if ((sign(av1) =sign(bv1) and min(aa/bb,bb/aa)>igama)) or maxv=<0  then do;
  oa=round(.5+rnd*nva);
  ob=round(.5+rnd*nvb);
  vat=va{oa};vbt=vb{ob};
 end;
end;**of ContPess;

***Sign: draw from distribution with diminishing sensitivity********;
if simtec='sign' then do; suma=0; sumb=0; 
 if r<7 then do; 
  do qq=1 to nva; suma=sum(suma,pa{qq}); if suma>rnd then do; vat=range*sign(va{qq}); qq=nva; end; end;
  do qq=1 to nvb; sumb=sum(sumb,spb{qq}); if sumb>rnd then do; vbt=range*sign(vb{qq}); qq=nvb; end; end;
 end;
 if r>=7 then do; 
  tmp=round(.5+ranuni(0)*(r-5)); vat=sign(his{1,tmp})*(maxv-minv); vbt=sign(his{2,tmp})*(maxv-minv); 
 end;
end;  ***of simtec=sign;

Bbet=Bbet+(vbt-vat)/ikapa;
end;**of ikapa samples;

***update beliefs****;
if  r>5 then do; rnds=ranuni(0); rndr=ranuni(0); if corr=1 then rndr=rnds; if corr=-1 then rndr=1-rnds;
 suma=0; sumb=0; 
 do qq=1 to nva; suma=sum(suma,pa{qq}); if suma>rnds then do; his{1,r-5}=va{qq}; qq=nva; end; end; 
 do qq=1 to nvb; sumb=sum(sumb,pb{qq}); if sumb>rndr then do; his{2,r-5}=vb{qq}; qq=nvb; end; end;
ww=nt/(nt+1);  if model='BEASTsd' then ww=iwamb;***********************************************************new BEASTsd;
if Amb=1 then sevb=sevb*(1-ww)+his{2,r-5}*ww; 

***near dom amb for BEASTsd*******************************************************************************newBEASTsd;

if model='BEASTsd' then do;
 if his{2,r-5} >= his{1,r-5} then obbet=obbet+1; 
 if his{1,r-5} >= his{2,r-5} then oabet=oabet+1;
 sumbb=sumbb+his{2,r-5}; aveb=sumbb/(r-5);
 if amb=1 and dom<1 and ewa>=ewb and eva>aveb then isigi =isig*(1-oabet/(r-5));
 if amb=1 and dom<1 and ewa=<ewb and eva<aveb then isigi =isig*(1-obbet/(r-5));
end; **of ne BEASTsd;

end;

***** updating the statistics**************;
Bchoice=0; if Bbet=0 then bchoice=.5; if Bbet>0 then bchoice=1;
pred{b}=sum(pred{b},Bchoice/(n_exp*5));
 
end; ** or r trials;

end;***of N_exp;

msd=20*((b1-pred1)**2+(b2-pred2)**2+(b3-pred3)**2+(b4-pred4)**2+(b5-pred5)**2);


proc sort; by kapa sig teta beta psi gama sigcom wamb;


proc print noobs round;
var Problem  amb sigt Ha pHa La Hb pHb Lb  b1 b2 b3 b4 b5 pred1 pred2 pred3 pred4 pred5 msd; 
run;


proc sort; by kapa sig teta beta psi gama sigcom wamb;
proc means data=a noprint; 
by kapa sig teta beta psi gama sigcom wamb;
var msd ;
output out=o mean= msd n=n;

proc sort; by msd;

proc print;
var  kapa sig teta beta psi gama sigcom wamb n msd;

run;

