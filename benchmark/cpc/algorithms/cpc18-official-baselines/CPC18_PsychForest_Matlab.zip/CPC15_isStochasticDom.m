function [ is, which ] = CPC15_isStochasticDom( DistA, DistB )
%Check if one distribution dominates stochastically the other
%   Input: 2 discrete distributions which are set as matrices of 1st column
%   as outcome and 2nd its probability. Output: 'is' a logical output,
%   'which' a char output ('A', 'B', NaN)

na= size(DistA,1);
nb= size(DistB,1);
if na == nb && prod(prod(DistA == DistB))
    is = false;
    which = NaN;
else
    tempa = ones(na,1);
    tempb = ones(nb,1);
    for i = 1 : nb
        sumpa = 0;%DistA(i,2);
        j = 1;
        sumpb =sum(DistB(1:i,2));
        while sumpa ~= 1 && j<=na && sumpa + DistA(j,2)  <= sumpb 
            sumpa = sumpa + DistA(j,2);
            if sumpa == sumpb
                break
            end
            j = j +1;
        end
        if j > na 
            j = na;
        end
        if DistB(i,1) < DistA(j,1)    
           tempb(i) = 0;
           break
        end  
    end

    if prod(tempb)
        is = true;
        which = 'B';
    else
        for i = 1 : na
            sumpb = 0;%DistA(i,2);
            j = 1;
            sumpa =sum(DistA(1:i,2));
            while sumpb ~= 1 && j<= nb && sumpb + DistB(j,2)  <= sumpa 
                sumpb = sumpb + DistB(j,2);
                if sumpa == sumpb
                    break
                end
                j = j +1;
            end
            if j > nb 
                j = nb;
            end
            if DistA(i,1) < DistB(j,1)    
               tempa(i) = 0;
               break
            end  
        end
        if prod(tempa)
            is = true;
            which = 'A';
        else
            is = false;
            which = NaN;
        end
    end
end      
    
end


