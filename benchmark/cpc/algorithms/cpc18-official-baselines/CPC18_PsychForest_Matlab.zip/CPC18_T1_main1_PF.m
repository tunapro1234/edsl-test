%  clear all
%% Section A: Please change this section to upload any necessary data
load('PF_TrainSet.mat');

%% Section B: Please do not change this section
% load estimation set problems
load('CPC18_EstSet.mat');
Data = DataEst;

% Simulate model
nProblems = length(Data.GameID(:));
PredictedAll = NaN(nProblems,5);
%% Section C: Please only change Lines 29-34 in this section
for prob = 1:nProblems
    % read problem's parameters
    Ha = Data.Ha(prob);
    pHa = Data.pHa(prob);
    La = Data.La(prob);
    LotShapeA = Data.LotShapeA(prob);
    LotNumA = Data.LotNumA(prob);
    Hb = Data.Hb(prob);
    pHb = Data.pHb(prob);
    Lb = Data.Lb(prob);
    LotShapeB = Data.LotShapeB(prob);
    LotNumB = Data.LotNumB(prob);
    Amb = Data.Amb(prob);
    Corr = Data.Corr(prob);

%%% please plug in here your model that takes as input the 12 parameters
%%% defined above and gives as output a vector size 5 named "Prediction" 
%%% in which each cell is the predicted B-rate for one block of five trials
%%% example:  
Prediction = CPC18_PF_pred(TrainData, Ha, pHa, La, LotShapeA, LotNumA, Hb, pHb, Lb, LotShapeB, LotNumB, Amb, Corr );
%%% end of example
    PredictedAll(prob,:) = Prediction;    
  prob
end

%% Section D: Please do not change this section 
% compute MSE
ObservedAll = Data{:, {'B1', 'B2', 'B3', 'B4', 'B5'}};
probMSDs = 100*mean((PredictedAll - ObservedAll).^2,2);
totalMSD = mean(probMSDs)
