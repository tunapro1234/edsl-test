function [ Feats ] = get_PF_Features(Ha, pHa, La, LotShapeA, LotNumA, Hb, pHb, Lb, LotShapeB, LotNumB, Amb, Corr)
% Finds the values of the engineered features that are part of Psychological Forest
%  Gets as input the parameters defining the choice problem in CPC18 and returns 
%  as output a dataframe with this problem's features
  
%  Compute the distribution's standard deviation
function [ SD ] = getSD(vals,probs)
    m = vals'*probs;
    sqds= (vals-m).^2;
    var = probs'*sqds;
    SD = (sqrt(var));
end

% defaults for function get_pBetter
defaultAccuracy = 10000;
defaultCorr = 1;

%% get "naive" and "psychological" features as per Plonsky, Erev, Hazan, and Tennenholtz, 2017
DistA = CPC18_getDist(Ha, pHa, La, LotShapeA, LotNumA);
DistB = CPC18_getDist(Hb, pHb, Lb, LotShapeB, LotNumB);
diffEV = ((DistB(:,1)'*DistB(:,2)) - (DistA(:,1)'*DistA(:,2)));
diffSDs = (getSD(DistB(:,1),DistB(:,2)) - getSD(DistA(:,1),DistA(:,2)));
MinA = DistA(1,1);
MinB = DistB(1,1);
diffMins = MinB - MinA;
nA = size(DistA,1);
nB = size(DistB,1);
MaxA = DistA(nA,1);
MaxB = DistB(nB,1);
diffMaxs = MaxB - MaxA;

diffUV = (DistB(:,1)'*((1/nB)*ones(nB,1))) - ((DistA(:,1)'*(1/nA)*ones(nA,1)));
if Amb == 1 
  ambiguous = true;
else
  ambiguous = false;
end
MaxOutcome = max([MaxA,MaxB]);
SignMax = sign(MaxOutcome);
if MinA == MinB
  RatioMin = 1;
elseif sign(MinA) == sign(MinB)
  RatioMin = min(abs(MinA),abs(MinB))/max(abs(MinA),abs(MinB)); 
else 
RatioMin = 0;
end
Range = MaxOutcome - min([MinA, MinB]);
diffSignEV = ((Range*(sign(DistB(:,1)))'*DistB(:,2)) - (Range*(sign(DistA(:,1)))'*DistA(:,2)));
[istriv, whchdom] = CPC15_isStochasticDom( DistA, DistB );
Dom = 0;
if (istriv)&&(whchdom == "A") 
  Dom = -1;
end
if (istriv)&&(whchdom == "B")
  Dom = 1;
end
BEVa = DistA(:,1)'*DistA(:,2);
if ambiguous
UEVb = DistB(:,1)'*((1/nB)*ones(nB,1));
BEVb = (UEVb+BEVa+MinB)/3 ;
pEstB = (1/nB)*ones(nB,1);% estimation of probabilties in Amb
t_SPminb = (BEVb -mean(DistB(2:nB,1)))/(MinB-mean(DistB(2:nB,1)));
if t_SPminb < 0 
    pEstB(1) = 0;
elseif t_SPminb > 1
    pEstB(1) = 1;
else
    pEstB(1) = t_SPminb;
end
pEstB(2:nB) = (1-pEstB(1))/(nB-1);
else
pEstB = DistB(:,2);
BEVb = DistB(:,1)'*pEstB;
end
diffBEV0 = (BEVb - BEVa);
BEVfb = (BEVb+(DistB(:,1)'*DistB(:,2)))/2;
diffBEVfb = (BEVfb - BEVa);

sampleDistB = [DistB(:,1),pEstB];
probsBetter = get_pBetter(DistA,sampleDistB,defaultCorr,defaultAccuracy);
pAbetter = probsBetter(1);
pBbetter = probsBetter(2);
pBbet_Unbiased1 = pBbetter - pAbetter;

sampleUniDistA = [DistA(:,1),(1/nA)*ones(nA,1)];
sampleUniDistB = [DistB(:,1),(1/nB)*ones(nB,1)];
probsBetterUni = get_pBetter(sampleUniDistA,sampleUniDistB,defaultCorr,defaultAccuracy);
pBbet_Uniform = probsBetterUni(2) - probsBetterUni(1);

sampleSignA = DistA;
sampleSignA(:,1) = sign(sampleSignA(:,1));
sampleSignB = [sign(DistB(:,1)),pEstB];
probsBetterSign = get_pBetter(sampleSignA,sampleSignB,defaultCorr,defaultAccuracy);
pBbet_Sign1 = probsBetterSign(2) - probsBetterSign(1);
sampleSignBFB = [sign(DistB(:,1)),DistB(:,2)];
if Corr == 1
probsBetter = get_pBetter(DistA,DistB,1,defaultAccuracy);
probsBetterSign = get_pBetter(sampleSignA,sampleSignBFB,1,defaultAccuracy);
elseif Corr == -1
probsBetter = get_pBetter(DistA,DistB,-1,defaultAccuracy);
probsBetterSign = get_pBetter(sampleSignA,sampleSignBFB,-1,defaultAccuracy);
else
probsBetter = get_pBetter(DistA,DistB,0,defaultAccuracy);
probsBetterSign = get_pBetter(sampleSignA,sampleSignBFB,0,defaultAccuracy);
end
pBbet_UnbiasedFB = probsBetter(2) - probsBetter(1);
pBbet_SignFB = probsBetterSign(2) - probsBetterSign(1);

%% create features table
tmpFeats = table(Ha, pHa, La, LotShapeA, LotNumA, Hb, pHb, Lb, LotShapeB, LotNumB, Amb, Corr,...
                    diffEV, diffSDs, diffMins, diffMaxs, diffUV, RatioMin, SignMax, pBbet_Unbiased1,...
                    pBbet_UnbiasedFB, pBbet_Uniform, pBbet_Sign1, pBbet_SignFB, Dom, diffBEV0, ...
                    diffBEVfb, diffSignEV);
% duplicate table as per number of blocks
Feats = repmat(tmpFeats,5,1);

%% get (original) BEAST prediction as feature
beastPs = CPC15_BEASTpred(Ha, pHa, La, LotShapeA, LotNumA, Hb, pHb, Lb, LotShapeB, LotNumB, Amb, Corr);
Feats.BEASTpred = beastPs';

%% add final features
Feats.block = (1:5)';
Feats.Feedback = ones(5,1);
Feats.Feedback(Feats.block==1) = 0;

end
