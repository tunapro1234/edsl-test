function [ Prediction ] = CPC18_PF_pred( TrainData, Ha, pHa, La, LotShapeA, LotNumA, Hb, pHb, Lb, LotShapeB, LotNumB, Amb, Corr )
% Prediction of Psychological Forest for one problem 
%  This function gets as input 12 parameters which define a problem in CPC18
%  and outputs Psych. Forest's prediction in that problem for five blocks of 
%  five trials each (the first is without and the others are with feedback

%  get table of engineedred features's values for the prediction problem
Feats = get_PF_Features(Ha, pHa, La, LotShapeA, LotNumA, Hb, pHb, Lb, LotShapeB, LotNumB, Amb, Corr);

% fix type issues between train and test data
Feats.LotShapeA = categorical(Feats.LotShapeA,{'-','Symm','R-skew','L-skew'});
Feats.LotShapeB = categorical(Feats.LotShapeB,{'-','Symm','R-skew','L-skew'});
Feats.Corr = categorical(Feats.Corr,[-1,0,1]);
Feats.Dom = categorical(Feats.Dom,[-1,0,1]);
Feats.SignMax = categorical(Feats.SignMax,[-1,0,1]);
  
nRuns = 20;
Prediction = zeros(1,5);
for run = 1:nRuns
    % train a random forest algorithm using all supplied features of the train data
    rf.model = TreeBagger(500,TrainData(:,2:32),TrainData.B_rate,'Method','regression');
    % let the trained RF predict the prediction prbolem
    pred = predict(rf.model,Feats)';
    Prediction = Prediction + (1/nRuns)*pred;
end
end