function [ simPred ] = CPC15_BEASTsimulation(DistA, DistB, Amb, Corr)
% Single simulation (25 trials) of the original BEAST for one problem

%% parameters
SIGMA = 7;
KAPA = 3;
BETA = 2.6;
GAMA = 0.5;
PSI = 0.07;
THETA = 1;
%% other constants
nTrials = 25;
firstFeedback = 6;
nBlocks = 5;
%% draw personal traits
sigma = SIGMA*rand(1);
kapa = randi(KAPA);
beta = BETA*rand(1);
gama = GAMA*rand(1);
psi = PSI*rand(1);
theta = THETA*rand(1);
%% preallocation
pBias = zeros(nTrials - firstFeedback,1);
ObsPay = zeros(nTrials - firstFeedback,2); % observed outcomes in A (col1) and B (col2)
% ObsPayB = zeros(nTrials - firstFeedback,1); % observed outcomes in B
Decision = -999*ones(nTrials,1);
simPred = -999*ones(1,nBlocks);
%% Useful variables
nA = size(DistA,1); % num outcomes in A
nB = size(DistB,1); % num outcomes in B
if Amb == 1
    ambiguous = true;
else
    ambiguous = false;
end
nfeed = 0; % "t"; number of outcomes with feedback so far
pBias(nfeed+1) = beta/(beta+1+nfeed^theta);
MinA = DistA(1,1);
MinB = DistB(1,1);
MaxOutcome = max(DistA(nA,1),DistB(nB,1));
SignMax = sign(MaxOutcome);
if MinA == MinB
    RatioMin = 1;
elseif sign(MinA) == sign(MinB)
    RatioMin = min(abs(MinA),abs(MinB))/max(abs(MinA),abs(MinB));
else
    RatioMin = 0;
end
Range = MaxOutcome - min(MinA, MinB);
trivial = CPC15_isStochasticDom( DistA, DistB );
% usepEstB = true;
%% Best estimate (0)
BEVa = (DistA(:,1)')*DistA(:,2); 
if ambiguous
    UEVb = (DistB(:,1)')*((1/nB)*ones(nB,1));
    BEVb = (1-psi)*mean([UEVb BEVa]) + psi*MinB;
    pEstB = zeros(nB,1); % estimation of probabilties in Amb
    t_SPminb = (BEVb -mean(DistB(2:nB,1)))/(MinB-mean(DistB(2:nB,1)));
    if t_SPminb < 0 
        pEstB(1) = 0;
    elseif t_SPminb > 1 
        pEstB(1) = 1;
    else
        pEstB(1) = t_SPminb;
    end
    pEstB(2:nB) = (1-pEstB(1))/(nB-1);
else
    pEstB = DistB(:,2);
    BEVb = (DistB(:,1)')*pEstB;
end

%% simulation of decisions
for trial = 1:nTrials
    STa = 0;
    STb = 0;
    % mental simulations
    for s = 1:kapa
        rndNum = rand(2,1);
        if rndNum(1) > pBias(nfeed+1) % Unbiased technique
            if nfeed == 0 
                outcomeA = distSample(DistA(:,1),DistA(:,2),rndNum(2));
                outcomeB = distSample(DistB(:,1),pEstB,rndNum(2));
            else
                uniprobs = (1/nfeed)*ones(nfeed,1);
                outcomeA = distSample(ObsPay(1:nfeed,1),uniprobs,rndNum(2));
                outcomeB = distSample(ObsPay(1:nfeed,2),uniprobs,rndNum(2));
            end           
        elseif rndNum(1) > (2/3)*pBias(nfeed+1) %uniform
            outcomeA = distSample(DistA(:,1),(1/nA)*ones(nA,1),rndNum(2));
            outcomeB = distSample(DistB(:,1),(1/nB)*ones(nB,1),rndNum(2));
        elseif rndNum(1) > (1/3)*pBias(nfeed+1) %contingent pessimism
            if SignMax > 0 && RatioMin < gama
                outcomeA = MinA;
                outcomeB = MinB;
            else
                outcomeA = distSample(DistA(:,1),(1/nA)*ones(nA,1),rndNum(2));
                outcomeB = distSample(DistB(:,1),(1/nB)*ones(nB,1),rndNum(2));
            end
        else % Sign
            if nfeed == 0 
                outcomeA = Range * distSample(sign(DistA(:,1)),DistA(:,2),rndNum(2));
                outcomeB = Range * distSample(sign(DistB(:,1)),pEstB,rndNum(2));
            else
                uniprobs = (1/nfeed)*ones(nfeed,1);
                outcomeA = Range * distSample(sign(ObsPay(1:nfeed,1)),uniprobs,rndNum(2));
                outcomeB = Range * distSample(sign(ObsPay(1:nfeed,2)),uniprobs,rndNum(2));
            end
        end
        STa = STa + outcomeA;
        STb = STb + outcomeB;
    end
    STa = STa/kapa;
    STb = STb/kapa;
    
    % error term
    if trivial
        error = 0;
    else
        error = sigma*randn(1); % positive values contribute to attraction to A
    end
    
    % decision
    Decision(trial) = (BEVa - BEVb) + (STa - STb) + error < 0;
    if (BEVa - BEVb) + (STa - STb) + error == 0
        Decision(trial) = randi(2) - 1;
    end
                
    if trial >= firstFeedback % got feedback
        nfeed = nfeed +1;
        pBias(nfeed+1) = beta/(beta+1+nfeed^theta);
        rndNumObs = rand(1);
        ObsPay(nfeed,1) = distSample(DistA(:,1),DistA(:,2),rndNumObs); % draw outcome from A
        if Corr == 1
            ObsPay(nfeed,2) = distSample(DistB(:,1),DistB(:,2),rndNumObs);
        elseif Corr == -1
            ObsPay(nfeed,2) = distSample(DistB(:,1),DistB(:,2),1-rndNumObs);
        else
            ObsPay(nfeed,2) = distSample(DistB(:,1),DistB(:,2),rand(1)); % draw outcome from B
        end
        if ambiguous
            BEVb = (1-1/(nTrials-firstFeedback+1))*BEVb + 1/(nTrials-firstFeedback+1)*ObsPay(nfeed,2);
        end
    end
end

% compute B-rates for this simulation
blockSize = nTrials/nBlocks;
for b = 1:nBlocks
    simPred(b) = mean(Decision(((b-1)*blockSize+1):(b*blockSize)));
end

end

